
public class ContaPoupança extends Conta{
    public String getTipoConta() {
        return tipoConta;
    }

    public void setTipoConta(String conta) {
        super.tipoConta = "Conta Corrente";
    }    
}
